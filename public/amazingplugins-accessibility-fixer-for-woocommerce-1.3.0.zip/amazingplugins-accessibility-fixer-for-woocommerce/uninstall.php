<?php
/**
 * Uninstall - cleans up all plugin data.
 *
 * Runs when the plugin is deleted (not just deactivated).
 * Uses WordPress native APIs so it works correctly across all setups.
 *
 * @package AmazingPlugins\WCAF
 */

declare(strict_types=1);

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

global $wpdb;

// Drop custom tables.
$tables = array(
	$wpdb->prefix . 'wcaf_fix_log',
	$wpdb->prefix . 'wcaf_scan_results',
);

foreach ( $tables as $table ) {
	$wpdb->query( "DROP TABLE IF EXISTS {$table}" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedVariableNotPrepared -- $table uses $wpdb->prefix + constant, table names cannot use prepared statement placeholders
}

// Remove all plugin options.
foreach (
	array(
		'wcaf_activated',
		'wcaf_active_fixes',
		'wcaf_scan_results',
		'wcaf_quota_used',
		'wcaf_quota_reset_at',
		'wcaf_site_url',
		'wcaf_notify_email',
		'wcaf_slack_webhook',
	) as $option
) {
	delete_option( $option );
}

// Remove any transients.
delete_transient( 'wcaf_scan_results' );
