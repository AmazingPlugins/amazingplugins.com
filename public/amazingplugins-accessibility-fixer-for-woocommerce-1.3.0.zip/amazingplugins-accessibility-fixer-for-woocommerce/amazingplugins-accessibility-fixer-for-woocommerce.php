<?php
/**
 * Plugin Name: AmazingPlugins Accessibility Fixer for WooCommerce
 * Plugin URI: https://amazingplugins.com
 * Description: One-click WCAG 2.1 AA compliance fixes for WooCommerce stores. Automatically fixes missing alt text, keyboard navigation, focus indicators, form labels, color contrast, and more.
 * Version: 1.3.0
 * Requires at least: 5.9
 * Tested up to: 6.9
 * Requires PHP: 7.4
 * Requires Plugins: woocommerce
 * Author: AmazingPlugins
 * Author URI: https://amazingplugins.com
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: amazingplugins-accessibility-fixer-for-woocommerce
 *
 * @package AmazingPlugins\WCAF
 */

declare(strict_types=1);

namespace AmazingPlugins\WCAF;

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Plugin version.
define( 'WCAF_VERSION', '1.3.0' );
define( 'WCAF_PLUGIN_FILE', __FILE__ );
define( 'WCAF_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'WCAF_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'WCAF_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );

/**
 * PSR-4 autoloader.
 *
 * @param string $class Fully qualified class name.
 */
spl_autoload_register(
	function ( string $class ): void {
		$prefix   = 'AmazingPlugins\\WCAF\\';
		$base_dir = WCAF_PLUGIN_DIR . 'src/';

		$len = strlen( $prefix );
		if ( strncmp( $prefix, $class, $len ) !== 0 ) {
			return;
		}

		$relative_class = substr( $class, $len );
		$file           = $base_dir . str_replace( '\\', '/', $relative_class ) . '.php';

		if ( file_exists( $file ) ) {
			require $file;
		}
	}
);

// phpcs:disable Generic.NamingConventions.UpperCaseConstantFound
/**
 * Bootstrap the plugin.
 *
 * @SuppressWarnings(PHPCS)
 */
function bootstrap(): void {
	require_once WCAF_PLUGIN_DIR . 'src/Core/Config.php';
	require_once WCAF_PLUGIN_DIR . 'src/Core/Logger.php';
	require_once WCAF_PLUGIN_DIR . 'src/Core/Plugin.php';

	// @codingStandardsIgnoreLine - WordPress core hook, cannot be prefixed.
	add_action( 'plugins_loaded', array( Core\Plugin::class, 'init' ) );

	// Deferred setup hook - runs once after activation in an admin context.
	// @codingStandardsIgnoreLine - WordPress core hook, cannot be prefixed.
	add_action( 'wcaf_deferred_setup', array( Core\Plugin::class, 'runDeferredSetup' ) );
}

bootstrap();
