<?php
// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
// Exit if accessed directly.
if (! defined('ABSPATH')) {
	exit;
}
?>
{{-- Accessibility Compliance Report - Admin View --}}
<div class="wrap wcaf-wrap wcaf-report-wrap">
    <h1>
        <?php esc_html_e('Accessibility Compliance Report', 'amazingplugins-accessibility-fixer-for-woocommerce'); ?>
    </h1>
    <p class="subtitle">
        <?php printf(
            /* translators: %s: Scan timestamp */
            esc_html__('Scanned: %s', 'amazingplugins-accessibility-fixer-for-woocommerce'),
            esc_html($scan_timestamp)
        ); ?>
        ?>
    </p>

    {{-- Severity Summary Cards --}}
    <div class="wcaf-cards wcaf-report-summary">
        <?php foreach ($severity_labels as $sev => $label): ?>
            <div class="wcaf-card wcaf-severity-card wcaf-severity-<?php echo esc_attr($sev); ?>">
                <h2><?php echo esc_html($label); ?></h2>
                <p class="wcaf-severity-count"><?php echo esc_html((string) $by_severity[$sev]); ?></p>
            </div>
        <?php endforeach; ?>
        <div class="wcaf-card wcaf-severity-card wcaf-severity-total">
            <h2><?php esc_html_e('Total', 'amazingplugins-accessibility-fixer-for-woocommerce'); ?></h2>
            <p class="wcaf-severity-count"><?php echo esc_html((string) $total_violations); ?></p>
        </div>
    </div>

    {{-- Export Actions --}}
    <p class="wcaf-report-actions">
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="display:inline-block;">
            <input type="hidden" name="action" value="wcaf_generate_pdf">
            <input type="hidden" name="_wcaf_nonce" value="<?php echo esc_attr($pdf_nonce); ?>">
            <button type="submit" class="button button-primary">
                <?php esc_html_e('Export Report (HTML)', 'amazingplugins-accessibility-fixer-for-woocommerce'); ?>
            </button>
        </form>
        <a href="<?php echo esc_url(admin_url('admin.php?page=wcaf')); ?>" class="button">
            <?php esc_html_e('Back to Dashboard', 'amazingplugins-accessibility-fixer-for-woocommerce'); ?>
        </a>
    </p>

    {{-- Per-Page Violation Tables --}}
    <?php foreach ($results['pages'] as $url => $violations): ?>
        <?php if (empty($violations)) { continue; } ?>
        <div class="wcaf-card wcaf-report-page">
            <h2 class="wcaf-report-page-title">
                <a href="<?php echo esc_url($url); ?>" target="_blank" rel="noopener">
                    <?php echo esc_url($url); ?>
                </a>
            </h2>
            <table class="widefat striped wcaf-report-table">
                <thead>
                    <tr>
                        <th><?php esc_html_e('Severity', 'amazingplugins-accessibility-fixer-for-woocommerce'); ?></th>
                        <th><?php esc_html_e('Issue', 'amazingplugins-accessibility-fixer-for-woocommerce'); ?></th>
                        <th><?php esc_html_e('Element', 'amazingplugins-accessibility-fixer-for-woocommerce'); ?></th>
                        <th><?php esc_html_e('WCAG', 'amazingplugins-accessibility-fixer-for-woocommerce'); ?></th>
                        <th><?php esc_html_e('Message', 'amazingplugins-accessibility-fixer-for-woocommerce'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($violations as $key => $v): ?>
                        <tr>
                            <td>
                                <span class="wcaf-badge wcaf-badge-<?php echo esc_attr($v['severity'] ?? 'minor'); ?>">
                                    <?php echo esc_html(strtoupper($v['severity'] ?? 'minor')); ?>
                                </span>
                            </td>
                            <td><?php echo esc_html(Config::getFixLabel($key)); ?></td>
                            <td><code><?php echo esc_html($v['element'] ?? ''); ?></code></td>
                            <td>
                                <span class="wcaf-wcag">
                                    <?php echo esc_html(Config::WCAG_CRITERIA[$key] ?? '?'); ?>
                                </span>
                            </td>
                            <td><?php echo esc_html($v['message'] ?? ''); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endforeach; ?>

    <?php if ($total_violations === 0): ?>
        <div class="wcaf-card">
            <h2><?php esc_html_e('All Clear!', 'amazingplugins-accessibility-fixer-for-woocommerce'); ?></h2>
            <p><?php esc_html_e('No accessibility violations were found on the scanned pages.', 'amazingplugins-accessibility-fixer-for-woocommerce'); ?></p>
        </div>
    <?php endif; ?>
</div>
