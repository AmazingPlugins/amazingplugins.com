(function ($) {
    'use strict';

    $(document).ready(function () {

        // ── Run Scan ──────────────────────────────────────────────────────────
        $('#wcaf-run-scan').on('click', function () {
            var $btn = $(this);
            $btn.prop('disabled', true).text(wcaf.i18n.scanning || 'Scanning…');
            $('#wcaf-scan-progress').show();

            $.post(wcaf.ajaxUrl, {
                action: 'wcaf_run_scan',
                nonce: wcaf.scanNonce
            }, function (res) {
                if (res.success) {
                    $btn.text(wcaf.i18n.rescan || 'Rescan').prop('disabled', false);
                    location.reload();
                } else {
                    alert((res.data && res.data.message) || 'Scan failed.');
                    $btn.text(wcaf.i18n.runScan || 'Run Scan Now').prop('disabled', false);
                }
            }).fail(function () {
                alert('Request failed. Please try again.');
                $btn.text(wcaf.i18n.runScan || 'Run Scan Now').prop('disabled', false);
            });
        });

        // ── Apply Fix ─────────────────────────────────────────────────────────
        $('.wcaf-apply-fix').on('click', function () {
            var $btn   = $(this);
            var fixKey = $btn.data('fix');
            var nonce  = $btn.data('nonce');

            $btn.prop('disabled', true).text(wcaf.i18n.applying || 'Applying…');

            $.post(wcaf.ajaxUrl, {
                action: 'wcaf_apply_fix',
                nonce: nonce,
                fix_key: fixKey
            }, function (res) {
                if (res.success) {
                    $btn
                        .removeClass('button-secondary')
                        .addClass('button-primary')
                        .text(wcaf.i18n.applied || 'Applied')
                        .prop('disabled', true);
                } else {
                    alert((res.data && res.data.message) || 'Failed to apply fix.');
                    $btn.text(wcaf.i18n.autoFix || 'Auto-Fix').prop('disabled', false);
                }
            }).fail(function () {
                alert('Request failed. Please try again.');
                $btn.text(wcaf.i18n.autoFix || 'Auto-Fix').prop('disabled', false);
            });
        });

    });

}(jQuery));
