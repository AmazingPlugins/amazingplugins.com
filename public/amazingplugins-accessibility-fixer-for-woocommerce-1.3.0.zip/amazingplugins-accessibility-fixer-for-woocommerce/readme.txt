=== AmazingPlugins Accessibility Fixer for WooCommerce ===
Contributors: amazingplugins
Tags: accessibility, woocommerce, wcag, ada, keyboard-navigation
Requires at least: 5.9
Tested up to: 6.9
Requires PHP: 7.4
Stable tag: 1.3.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Automatically fix WCAG 2.1 AA accessibility issues on your store. No code needed.

== Description ==

WooCommerce stores are increasingly targeted by ADA accessibility lawsuits. Most issues are code-level problems that can be automatically fixed - without a developer, without an expensive agency audit, and without an overlay widget that doesn't actually fix your code.

This plugin scans your WooCommerce pages, identifies WCAG 2.1 AA violations, and applies real code-level fixes automatically.

**How is this different from overlay tools like AccessiBe or UserWay?**

Overlay tools add a JavaScript widget on top of your site that modifies how the page looks in the browser. They don't change your underlying HTML - so WAVE and axe DevTools still detect violations, and courts increasingly see through them.

This plugin actually fixes your code. Automated accessibility testing passes. Your site is genuinely more accessible.

What the plugin fixes:

1. **Missing alt text on product images** - alt text is auto-generated or applied based on product data
2. **Low color contrast** - text/background contrast is adjusted to meet 4.5:1 ratio
3. **Missing form labels** - labels are injected for checkout and account forms
4. **Missing focus indicators** - keyboard focus rings are styled to be visible
5. **Missing skip links** - skip-to-content links are added for keyboard users
6. **Keyboard traps** - modal and menu keyboard traps are removed
7. **Incorrect heading hierarchy** - H tags are corrected to follow logical structure
8. **Missing landmarks** - ARIA landmarks are added to page sections
9. **Missing error messages** - inline error messages are added to form validation

**No limits, no Pro version.** All 9 fixers are fully functional in the free plugin - run unlimited scans and apply fixes as needed.

== Installation ==

1. Upload the plugin folder to `/wp-content/plugins/` or install via the WordPress Plugins screen
2. Activate through the 'Plugins' menu in WordPress
3. Navigate to **WooCommerce → WCAG Auto-Fix** in the admin menu
4. Run your first scan
5. Apply fixes from the dashboard

== Frequently Asked Questions ==

= Does this make my WooCommerce store fully ADA compliant? =

No tool makes a site fully ADA compliant automatically. This plugin fixes code-level WCAG 2.1 AA issues continuously and represents a genuine, ongoing accessibility effort. Combined with periodic manual audits, this demonstrates the kind of good-faith compliance effort courts look for.

= Is this different from AccessiBe or UserWay? =

Yes. Overlay tools add a JavaScript widget that modifies your page in the browser. They don't fix your underlying HTML - automated testing tools still detect violations. This plugin actually changes your code. WAVE and axe DevTools will show fewer violations after fixes are applied.

= Does this work with my theme? =

The plugin targets standard WooCommerce hooks and templates. Most popular themes (Flatsome, Astra, Divi, OceanWP, Storefront) are supported. Themes with heavy customizations may require additional fixes.

= Will this slow down my store? =

The plugin is lightweight. Fixes are applied at render time with minimal overhead. Performance impact is tested against Lighthouse scores.

= Does this handle checkout forms? =

Yes. The plugin targets WooCommerce checkout forms, account forms, and product pages - the areas most commonly cited in accessibility lawsuits.

= What happens when I uninstall? =

Uninstalling removes all injected fixes and cleans up the database. Your original theme and WooCommerce templates are restored.

== Screenshots ==

1. Dashboard showing accessibility scan results and fix summary
2. Settings panel - configure which fixers to enable/disable
3. Detailed scan results with issues organized by severity
4. Individual fixer view showing before/after
5. Scan history with severity breakdown

== Changelog ==

= 1.3.0 =
* Removed: all Pro/Free locking, quota system, and subscription tiers - plugin is now fully free and unlimited
* Updated: readme.txt to remove Free/Pro plan references

= 1.2.1 =
* Fixed: WordPress.org plugin review issues (PHP version check, PHPCS suppressions, REST nonce handling)
* Added: uninstall.php cleanup for all plugin options and tables
* Changed: all fixers free and unlimited - no quotas, no Pro version

= 1.1.3 =
* Added: scan history table on the dashboard
* Fixed: PHP 8.2 compatibility on enum-style class constants
* Improved: scan page UI with severity breakdown

= 1.1.2 =
* Added: PDF report generation
* Added: Slack webhook notifications
* Improved: scan performance on stores with 100+ products

= 1.1.1 =
* Fixed: alt text fixer not applying to product gallery images
* Fixed: skip link injection conflicting with theme skip links
* Improved: WooCommerce 8.7 compatibility

= 1.1.0 =
* Added: email notification on scan completion
* Added: WCAG 2.1 AA criteria reference in fix labels
* Improved: dashboard card layout
* Fixed: color contrast fixer not reading computed styles correctly

= 1.0.1 =
* Fixed: activation redirect loop when WooCommerce is not active
* Fixed: plugin not loading translation files
* Added: Italian and Spanish translations

= 1.0.0 =
* Initial release
* 10 automated WCAG 2.1 AA fixers
* WooCommerce 7.0+ compatibility
* WordPress 5.8+ compatibility

== Upgrade Notice ==

= 1.3.0 =
All fixers are now completely free and unlimited - no quotas, no Pro version, no restrictions.

= 1.2.1 =
All fixers are now free and unlimited - no quotas, no Pro version.
