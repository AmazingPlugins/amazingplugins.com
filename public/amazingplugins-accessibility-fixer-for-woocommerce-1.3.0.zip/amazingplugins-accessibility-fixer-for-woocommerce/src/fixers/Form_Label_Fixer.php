<?php
declare(strict_types=1);

namespace AmazingPlugins\WCAF\Fixers;

defined( 'ABSPATH' ) || exit;

/**
 * Form Label Fixer.
 *
 * Adds aria-label to form inputs that have a placeholder but no visible label.
 * This implements WCAG technique G92 (using aria-label as a last resort).
 *
 * Uses the_content filter with a guard to prevent double-processing.
 * Falls back gracefully when DOMDocument fails to parse the content.
 */
class Form_Label_Fixer implements Fixer_Interface {

	private const HOOK_PRIORITY = 20;

	/** @var bool Prevents double-processing within the same PHP process (e.g. WP Rocket re-entrant calls). */
	private static bool $applied = false;

	private const SKIP_TYPES = array(
		'hidden' => true,
		'submit' => true,
		'button' => true,
		'reset'  => true,
		'image'  => true,
		'file'   => true,
	);

	public function getKey(): string {
		return 'form_label';
	}

	public function isFree(): bool {
		return true;
	}

	public function apply(): bool {
		add_filter( 'the_content', array( self::class, 'injectAriaLabels' ), self::HOOK_PRIORITY );
		return true;
	}

	public function revert(): bool {
		remove_filter( 'the_content', array( self::class, 'injectAriaLabels' ), self::HOOK_PRIORITY );
		return true;
	}

	/**
	 * Scan content for form inputs missing labels and add aria-label from
	 * placeholder attribute.
	 *
	 * @param string $content HTML content.
	 * @return string Filtered content.
	 */
	public static function injectAriaLabels( string $content ): string {
		if ( self::$applied ) {
			return $content;
		}
		self::$applied = true;

		if ( empty( $content ) || strpos( $content, '<input' ) === false ) {
			return $content;
		}

		libxml_use_internal_errors( true );
		$charset = mb_internal_encoding();
		$doc     = new \DOMDocument();

		// @ suppresses E_USER_DEPRECATED from mb_convert_encoding in PHP 8.x.
		$encoded = @mb_convert_encoding( $content, 'HTML-ENTITIES', $charset );
		// Wrap to prevent DOMDocument from adding html/body wrappers.
		$doc->loadHTML( '<div xmlns=\"http://www.w3.org/1999/xhtml\">' . $encoded . '</div>' );
		$xpath = new \DOMXPath( $doc );

		$inputs = $xpath->query(
			'//input[not(@type) or not(contains("hidden submit button reset image file", @type))]'
			. '[not(@aria-label)]'
			. '[not(@aria-labelledby)]'
			. '[not(ancestor::label[not(@for)])]'
		);

		foreach ( $inputs as $input ) {
			/** @var \DOMElement $input */
			$placeholder = $input->getAttribute( 'placeholder' );
			if ( $placeholder !== '' ) {
				// Sanitize the placeholder value before using it as aria-label.
				$input->setAttribute( 'aria-label', esc_attr( wp_strip_all_tags( $placeholder ) ) );
			}

			// Check for implicit label: <label for="id"><input id="id">.
			$id                         = $input->getAttribute( 'id' );
			$hasExplicitOrImplicitLabel = false;
			if ( $id !== '' ) {
				$labels = $xpath->query( '//label[@for="' . $id . '"]' );
				if ( $labels->length > 0 ) {
					$hasExplicitOrImplicitLabel = true;
				}
			}

			if ( ! $hasExplicitOrImplicitLabel ) {
				// No explicit or implicit label - check for previous sibling text.
				// Traverse previous siblings to find a non-empty text node or element.
				$prev = $input->previousSibling;
				while ( $prev ) {
					if ( $prev->nodeType === XML_TEXT_NODE ) {
						$text = trim( $prev->textContent );
						if ( $text !== '' ) {
							$input->setAttribute( 'aria-label', esc_attr( wp_strip_all_tags( $text ) ) );
							break;
						}
					} elseif ( $prev->nodeType === XML_ELEMENT_NODE ) {
						$text = trim( $prev->textContent );
						if ( $text !== '' ) {
							$input->setAttribute( 'aria-label', esc_attr( wp_strip_all_tags( $text ) ) );
							break;
						}
					}
					$prev = $prev->previousSibling;
				}
			}
		}

		// Extract the wrapper div's content by saving the div itself, then
		// strip the opening and closing div tags to avoid double-serialization.
		$divs = $xpath->query( '//div[@xmlns]' );
		if ( $divs->length > 0 ) {
			$divHtml = $doc->saveHTML( $divs->item( 0 ) );
			// Strip the opening <div...> and closing </div> tags.
			$output = preg_replace( '#^<div[^>]*>#', '', $divHtml );
			$output = preg_replace( '#</div>$#', '', $output );
		} else {
			$output = '';
		}

		return $output ?: $content;
	}

	/**
	 * Reset the applied flag. Used by tests to allow repeated calls in the same process.
	 */
	public static function reset(): void {
		self::$applied = false;
	}
}
