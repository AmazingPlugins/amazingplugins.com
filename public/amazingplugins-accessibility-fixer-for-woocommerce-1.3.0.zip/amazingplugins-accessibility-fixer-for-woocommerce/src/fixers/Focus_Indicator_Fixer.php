<?php
declare(strict_types=1);

namespace AmazingPlugins\WCAF\Fixers;

defined( 'ABSPATH' ) || exit;

/**
 * Focus Indicator Fixer.
 *
 * Applies WCAG 2.4.7-compliant :focus-visible styles via wp_add_inline_style -
 * no raw style echo.
 */
class Focus_Indicator_Fixer implements Fixer_Interface {

	private const HANDLE = 'wcaf-focus-indicator';

	public function getKey(): string {
		return 'focus_indicator';
	}

	public function isFree(): bool {
		return true;
	}

	public function apply(): bool {
		wp_register_style( self::HANDLE, false, array(), WCAF_VERSION );
		wp_enqueue_style( self::HANDLE );

		wp_add_inline_style(
			self::HANDLE,
			"/* WCAF: WCAG 2.4.7 focus indicator */\n"
				. ":focus-visible {\n"
				. "    outline: 3px solid #2271b1 !important;\n"
				. "    outline-offset: 2px !important;\n"
				. "}\n"
				. ":focus:not(:focus-visible) {\n"
				. "    outline: none !important;\n"
				. "}\n"
				. "/* Ensure interactive WooCommerce elements always show a focus ring */\n"
				. ".woocommerce a:focus,\n"
				. ".woocommerce button:focus,\n"
				. ".woocommerce input:focus,\n"
				. ".woocommerce select:focus,\n"
				. ".woocommerce textarea:focus,\n"
				. ".woocommerce label:focus {\n"
				. "    outline: 3px solid #2271b1 !important;\n"
				. "    outline-offset: 2px !important;\n"
				. "}\n"
		);

		return true;
	}

	public function revert(): bool {
		wp_dequeue_style( self::HANDLE );
		return true;
	}
}
