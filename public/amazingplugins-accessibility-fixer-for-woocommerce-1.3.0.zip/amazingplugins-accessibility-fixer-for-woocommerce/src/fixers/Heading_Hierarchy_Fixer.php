<?php
declare(strict_types=1);

namespace AmazingPlugins\WCAF\Fixers;

defined( 'ABSPATH' ) || exit;

/**
 * Heading Hierarchy Fixer.
 *
 * Hooks into 'the_content' to demote orphaned h4/h5/h6 headings that appear
 * without a parent h3 (suggesting a broken theme hierarchy).  This is a heuristic
 * fixer - it is intentionally conservative to avoid corrupting intentional markup.
 *
 * Note: the_content filters run on posts AND on WooCommerce descriptions which
 * contain raw HTML.  We guard with a static $applied flag to prevent double-
 * processing when plugins (e.g. WP Rocket) call the filter multiple times.
 */
class Heading_Hierarchy_Fixer implements Fixer_Interface {

	private const HOOK_PRIORITY = 20;

	/** @var bool Prevents double-processing within the same PHP process. */
	private static bool $applied = false;

	public function getKey(): string {
		return 'heading_hierarchy';
	}

	public function isFree(): bool {
		return true;
	}

	public function apply(): bool {
		add_filter( 'the_content', array( self::class, 'fixHeadings' ), self::HOOK_PRIORITY );
		return true;
	}

	public function revert(): bool {
		remove_filter( 'the_content', array( self::class, 'fixHeadings' ), self::HOOK_PRIORITY );
		return true;
	}

	/**
	 * Demote h4/h5/h6 that appear without any h3 ancestor in the same content.
	 *
	 * @param string $content Post / product content HTML.
	 * @return string Filtered content with demoted headings.
	 */
	public static function fixHeadings( string $content ): string {
		// Prevent double-processing in same request.
		if ( self::$applied ) {
			return $content;
		}
		self::$applied = true;

		// Guard: skip empty or non-HTML content.
		if ( empty( $content ) || strpos( $content, '<h' ) === false ) {
			return $content;
		}

		// Suppress warnings from malformed HTML.
		libxml_use_internal_errors( true );
		$charset = mb_internal_encoding();
		$doc     = new \DOMDocument();

		/*
		 * LoadHTML requires a full document.  Wrap in a div so we don't create
		 * spurious <html><body> wrappers.  Use ISO-8859-1 fallback encoding if
		 * mb_convert_encoding fails.
		 */
		// @ suppresses E_USER_DEPRECATED from mb_convert_encoding in PHP 8.x.
		$encoded = @mb_convert_encoding( $content, 'HTML-ENTITIES', $charset );
		$doc->loadHTML( '<div xmlns=\"http://www.w3.org/1999/xhtml\">' . $encoded . '</div>' );
		$xpath = new \DOMXPath( $doc );

		// Check if any h3 exists.  If not, demote the deepest orphan headings.
		$has_h3 = $xpath->query( '//h3' )->length > 0;

		if ( ! $has_h3 ) {
			$map = array(
				'h4' => 'h3',
				'h5' => 'h4',
				'h6' => 'h5',
			);
			foreach ( array( 'h6', 'h5', 'h4' ) as $tag ) {
				$elements = $xpath->query( '//' . $tag );
				foreach ( $elements as $el ) {
					$new_tag = $doc->createElement( $map[ $tag ] );
					// Copy all child nodes.
					foreach ( $el->childNodes as $child ) {
						$new_tag->appendChild( $child->cloneNode( true ) );
					}
					// Copy essential attributes (id, class) safely.
					if ( $el->hasAttribute( 'id' ) ) {
						$new_tag->setAttribute( 'id', $el->getAttribute( 'id' ) );
					}
					if ( $el->hasAttribute( 'class' ) ) {
						$new_tag->setAttribute( 'class', $el->getAttribute( 'class' ) );
					}
					$el->parentNode->replaceChild( $new_tag, $el );
				}
			}
		}

		// Extract just the inner div content.
		$nodes  = $xpath->query( '//div[@xmlns]/node()' );
		$output = '';
		foreach ( $nodes as $node ) {
			$output .= $doc->saveHTML( $node );
		}

		// Fallback: if extraction failed, return original content.
		return $output ?: $content;
	}

	/**
	 * Reset the applied flag. Used by tests to allow repeated calls in the same process.
	 */
	public static function reset(): void {
		self::$applied = false;
	}
}
