<?php
declare(strict_types=1);

namespace AmazingPlugins\WCAF\Fixers;

defined( 'ABSPATH' ) || exit;

/**
 * Keyboard Trap Fixer.
 *
 * Ensures modal / lightbox overlays can be dismissed with the Escape key,
 * satisfying WCAG 2.1.2 (No Keyboard Trap).  Uses wp_add_inline_script
 * so WordPress handles script loading order and duplication safety.
 */
class Keyboard_Trap_Fixer implements Fixer_Interface {

	private const HANDLE = 'wcaf-keyboard-trap';

	public function getKey(): string {
		return 'keyboard_trap';
	}

	public function isFree(): bool {
		return true;
	}

	public function apply(): bool {
		wp_register_script( self::HANDLE, '', array(), WCAF_VERSION, array( 'in_footer' => true ) );
		wp_enqueue_script( self::HANDLE );

		wp_add_inline_script(
			self::HANDLE,
			'(function(){'
				. "document.addEventListener('keydown',function(e){"
					. "if(e.key!=='Escape'){return;}"
					. "var modalSelectors=['.woocommerce-modal','[aria-modal=\"true\"]','.woocommerce-lightbox','.wc-modal','.modal'];"
					. 'modalSelectors.forEach(function(sel){'
						. 'document.querySelectorAll(sel).forEach(function(modal){'
							. 'var closeBtn=modal.querySelector('
								. "'button[aria-label=\"Close\"],button[aria-label=\"close\"],.wc-modal-close,[data-dismiss=\"modal\"],.woocommerce-store-icebergs-close'"
							. ');'
							. 'if(closeBtn){closeBtn.click();}'
						. '});'
					. '});'
				. '});'
			. '})();'
		);

		return true;
	}

	public function revert(): bool {
		wp_dequeue_script( self::HANDLE );
		return true;
	}
}
