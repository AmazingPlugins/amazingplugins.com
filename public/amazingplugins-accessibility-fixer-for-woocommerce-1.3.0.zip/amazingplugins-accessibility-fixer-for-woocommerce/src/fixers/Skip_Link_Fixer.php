<?php
declare(strict_types=1);

namespace AmazingPlugins\WCAF\Fixers;

defined( 'ABSPATH' ) || exit;

/**
 * Skip Link Fixer.
 *
 * Injects a WCAG-compliant skip-to-content link immediately after the opening
 * <body> tag and enqueues the corresponding focus styles via WordPress's
 * inline style API (no raw echo).
 */
class Skip_Link_Fixer implements Fixer_Interface {

	private const HANDLE        = 'wcaf-skip-link';
	private const SCRIPT_HANDLE = 'wcaf-skip-link';

	public function getKey(): string {
		return 'skip_link';
	}

	public function isFree(): bool {
		return true;
	}

	public function apply(): bool {
		// Register and enqueue the skip-link stylesheet fragment.
		wp_register_style( self::HANDLE, false, array(), WCAF_VERSION );
		wp_enqueue_style( self::HANDLE );
		wp_add_inline_style(
			self::HANDLE,
			'.wcaf-skip-link:focus{'
				. 'position:static !important;'
				. 'width:auto !important;'
				. 'height:auto !important;'
				. 'overflow:visible !important;'
				. 'padding:8px 16px !important;'
				. 'background:#21759b !important;'
				. 'color:#fff !important;'
				. 'text-decoration:none !important;'
				. 'border-radius:0 0 4px 4px !important;'
				. 'z-index:999999 !important;'
				. 'display:inline-block !important;'
			. '}'
		);

		// Register and enqueue the skip-link JS (injects HTML after body open).
		wp_register_script( self::SCRIPT_HANDLE, '', array(), WCAF_VERSION, array( 'in_footer' => false ) );
		wp_enqueue_script( self::SCRIPT_HANDLE );
		wp_add_inline_script(
			self::SCRIPT_HANDLE,
			'(function(){'
				. "var el=document.createElement('a');"
				. "el.className='wcaf-skip-link';"
				. "el.href='#main-content';"
				. 'el.textContent=' . wp_json_encode( esc_html__( 'Skip to main content', 'amazingplugins-accessibility-fixer-for-woocommerce' ) ) . ';'
				. "el.setAttribute('style',"
					. "'position:absolute;left:-9999px;top:auto;width:1px;height:1px;overflow:hidden;z-index:999999;'"
				. ');'
				. 'document.body.insertBefore(el,document.body.firstChild);'
			. '})();'
		);

		return true;
	}

	public function revert(): bool {
		wp_dequeue_style( self::HANDLE );
		wp_dequeue_script( self::SCRIPT_HANDLE );
		return true;
	}
}
