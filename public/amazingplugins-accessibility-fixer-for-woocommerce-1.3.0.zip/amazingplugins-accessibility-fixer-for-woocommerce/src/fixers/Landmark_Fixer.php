<?php
declare(strict_types=1);

namespace AmazingPlugins\WCAF\Fixers;

defined( 'ABSPATH' ) || exit;

/**
 * Landmark Fixer.
 *
 * Injects a <main> landmark wrapper around WooCommerce content areas that
 * lack one, satisfying WCAG 1.3.6 (Identify Landmarks).  Uses output buffering
 * via a dedicated template action - safe because it only targets WooCommerce
 * template hooks, not arbitrary content.
 */
class Landmark_Fixer implements Fixer_Interface {

	private const HANDLE = 'wcaf-landmark';

	public function getKey(): string {
		return 'landmark';
	}

	public function isFree(): bool {
		return true;
	}

	public function apply(): bool {
		// Register a minimal JS that adds role=main to the first content div.
		wp_register_script( self::HANDLE, '', array(), WCAF_VERSION, array( 'in_footer' => true ) );
		wp_enqueue_script( self::HANDLE );

		wp_add_inline_script(
			self::HANDLE,
			'(function(){'
				. "document.addEventListener('DOMContentLoaded',function(){"
					// Only act once.
					. "if(document.querySelector('[role=main]')){return;}"
					// Try common WooCommerce content wrappers.
					. "var targets=['.woocommerce-page .site-content','#content','#main','[id=\"woocommerce-document-wrap\"]'];"
					. 'for(var i=0;i<targets.length;i++){'
						. 'var el=document.querySelector(targets[i]);'
						. "if(el){el.setAttribute('role','main');return;}"
					. '}'
				. '});'
			. '})();'
		);

		return true;
	}

	public function revert(): bool {
		wp_dequeue_script( self::HANDLE );
		return true;
	}
}
