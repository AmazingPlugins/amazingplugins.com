<?php
declare(strict_types=1);

namespace AmazingPlugins\WCAF\Fixers;

defined( 'ABSPATH' ) || exit;

class Alt_Text_Fixer implements Fixer_Interface {

	private const HOOK_PRIORITY = 20;

	public function getKey(): string {
		return 'alt_text_product';
	}

	public function isFree(): bool {
		return true;
	}

	/**
	 * Hook into WooCommerce product image attribute filter.
	 * We add a high priority so we run after most other handlers.
	 */
	public function apply(): bool {
		add_filter(
			'wp_get_attachment_image_attributes',
			array( self::class, 'injectMissingAlt' ),
			self::HOOK_PRIORITY,
			2
		);

		// Also handle WooCommerce product gallery images.
		add_filter(
			'woocommerce_product_get_image',
			array( self::class, 'injectGalleryAlt' ),
			self::HOOK_PRIORITY,
			2
		);

		return true;
	}

	/**
	 * Revert: remove our attribute hooks.
	 */
	public function revert(): bool {
		remove_filter(
			'wp_get_attachment_image_attributes',
			array( self::class, 'injectMissingAlt' ),
			self::HOOK_PRIORITY
		);
		remove_filter(
			'woocommerce_product_get_image',
			array( self::class, 'injectGalleryAlt' ),
			self::HOOK_PRIORITY
		);
		return true;
	}

	/**
	 * Fill in missing alt text from the attachment's post title.
	 *
	 * @param array<string,string> $attr  Image attributes.
	 * @param \WP_Post             $attachment Attachment post object.
	 * @return array<string,string> Filtered attributes.
	 */
	public static function injectMissingAlt( array $attr, $attachment ): array {
		if ( ! $attachment instanceof \WP_Post ) {
			return $attr;
		}

		// Only fill if alt is genuinely empty.
		if ( ! empty( $attr['alt'] ) ) {
			return $attr;
		}

		$title = get_the_title( $attachment->ID );
		if ( $title ) {
			$attr['alt'] = esc_attr( $title );
		}

		return $attr;
	}

	/**
	 * Fill alt on WooCommerce product object images via their get_image call.
	 *
	 * @param string $image    HTML img tag or empty string.
	 * @param object $product   \WC_Product instance.
	 * @return string Filtered HTML.
	 */
	public static function injectGalleryAlt( string $image, $product ): string {
		if ( ! $product instanceof \WC_Product ) {
			return $image;
		}

		// Only act if our marker is not already present.
		if ( false !== strpos( $image, 'data-wcaf-alt-fixed' ) ) {
			return $image;
		}

		// Use product title as fallback alt.
		$product_title = esc_attr( $product->get_name() );
		$image         = str_replace( '<img ', '<img alt=\"' . $product_title . '\" data-wcaf-alt-fixed=\"1\" ', $image );

		return $image;
	}
}
