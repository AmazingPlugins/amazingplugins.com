<?php
declare(strict_types=1);

namespace AmazingPlugins\WCAF\Fixers;

defined( 'ABSPATH' ) || exit;

/**
 * Color Contrast Fixer.
 *
 * Enqueues high-contrast focus overrides and error border colours for common
 * WooCommerce form elements via wp_add_inline_style - no raw style echo.
 */
class Color_Contrast_Fixer implements Fixer_Interface {

	private const HANDLE = 'wcaf-color-contrast';

	public function getKey(): string {
		return 'color_contrast';
	}

	public function isFree(): bool {
		return true;
	}

	public function apply(): bool {
		wp_register_style( self::HANDLE, false, array(), WCAF_VERSION );
		wp_enqueue_style( self::HANDLE );

		wp_add_inline_style(
			self::HANDLE,
			"/* WCAF: High-contrast focus + error border overrides */\n"
				. ".woocommerce-checkout #billing_first_field_field input:focus,\n"
				. ".woocommerce-checkout .form-row input:focus,\n"
				. ".woocommerce-account .woocommerce-Address input:focus {\n"
				. "    outline-color: #21759b !important;\n"
				. "    outline-width: 3px !important;\n"
				. "    outline-style: solid !important;\n"
				. "    outline-offset: 2px !important;\n"
				. "}\n"
				. ".woocommerce form .form-row.woocommerce-invalid input,\n"
				. ".woocommerce form .form-row.woocommerce-invalid select,\n"
				. ".woocommerce form .form-row.woocommerce-invalid textarea {\n"
				. "    border-left-color: #d63638 !important;\n"
				. "    border-left-width: 3px !important;\n"
				. "}\n"
				. ".woocommerce .woocommerce-error,\n"
				. ".woocommerce span.err,\n"
				. ".woocommerce li.err {\n"
				. "    border-left-color: #d63638 !important;\n"
				. "}\n"
		);

		return true;
	}

	public function revert(): bool {
		wp_dequeue_style( self::HANDLE );
		return true;
	}
}
