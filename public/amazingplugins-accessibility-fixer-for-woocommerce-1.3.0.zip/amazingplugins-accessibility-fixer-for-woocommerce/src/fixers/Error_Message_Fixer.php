<?php
declare(strict_types=1);

namespace AmazingPlugins\WCAF\Fixers;

defined( 'ABSPATH' ) || exit;

/**
 * Error Message Fixer.
 *
 * Associates WooCommerce error messages with their related form fields via
 * aria-describedby so screen readers announce errors contextually.
 * Uses wp_add_inline_script - no raw JS echo.
 */
class Error_Message_Fixer implements Fixer_Interface {

	private const HANDLE = 'wcaf-error-message';

	public function getKey(): string {
		return 'error_message';
	}

	public function isFree(): bool {
		return true;
	}

	public function apply(): bool {
		wp_register_script( self::HANDLE, '', array(), WCAF_VERSION, array( 'in_footer' => true ) );
		wp_enqueue_script( self::HANDLE );

		wp_add_inline_script(
			self::HANDLE,
			'(function(){'
				. "document.addEventListener('DOMContentLoaded',function(){"
					. "document.querySelectorAll('.woocommerce-error,.woocommerce-error li').forEach(function(err){"
						. "var id=err.id||('wcaf_err_'+Math.random().toString(36).substr(2,9));"
						. 'if(!err.id){err.id=id;}'
						. 'var prev=err.previousElementSibling;'
						. 'if(!prev){return;}'
						. "prev.querySelectorAll('input,select,textarea').forEach(function(field){"
							. "var existing=field.getAttribute('aria-describedby')||'';"
							. 'var ids=existing?existing.split(/\\s+/):[];'
							. 'if(ids.indexOf(id)===-1){'
								. 'ids.push(id);'
								. "field.setAttribute('aria-describedby',ids.join(' '));"
							. '}'
						. '});'
					. '});'
				. '});'
			. '})();'
		);

		return true;
	}

	public function revert(): bool {
		wp_dequeue_script( self::HANDLE );
		return true;
	}
}
