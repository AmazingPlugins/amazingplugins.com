<?php
declare(strict_types=1);

namespace AmazingPlugins\WCAF\Fixers;

defined( 'ABSPATH' ) || exit;

interface Fixer_Interface {

	public function getKey(): string;
	public function isFree(): bool;
	public function apply(): bool;
	public function revert(): bool;
}
