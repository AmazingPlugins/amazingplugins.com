<?php
declare(strict_types=1);

namespace AmazingPlugins\WCAF\Reports;

defined( 'ABSPATH' ) || exit;

use AmazingPlugins\WCAF\Core\Config;

class Report_Generator {

	public static function generateTextReport( array $results ): string {
		$output  = "=== WooCommerce Accessibility Auto-Fixer ===\n";
		$output .= 'Scan Date: ' . esc_html( $results['scanned_at'] ) . "\n\n";

		foreach ( $results['pages'] as $url => $violations ) {
			if ( empty( $violations ) ) {
				continue;
			}
			$output .= 'Page: ' . esc_url( $url ) . "\n";
			foreach ( $violations as $key => $v ) {
				// Use concatenation instead of sprintf to avoid format-string issues
				// with user-controlled message values.
				$severity = strtoupper( $v['severity'] ?? 'minor' );
				$label    = Config::getFixLabel( $key );
				$wcag     = Config::WCAG_CRITERIA[ $key ] ?? '?';
				$msg      = $v['message'] ?? '';
				$output  .= "  [{$severity}] {$label} (WCAG {$wcag})\n    → {$msg}\n";
			}
			$output .= "\n";
		}

		return $output;
	}

	public static function generateHTMLReport( array $results ): string {
		ob_start();
		?>
		<html>
		<head>
			<meta charset="UTF-8">
			<title>Accessibility Compliance Report</title>
			<style>
				body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; max-width: 900px; margin: 0 auto; padding: 40px 20px; }
				h1 { color: #1d2327; }
				.page-section { margin-bottom: 32px; }
				.violation { background: #f0f6fc; border-left: 4px solid #d63638; padding: 12px 16px; margin: 8px 0; }
				.severity-critical { border-left-color: #d63638; }
				.severity-major { border-left-color: #ea7000; }
				.severity-minor { border-left-color: #007cba; }
				.summary-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); gap: 16px; }
				.summary-card { background: #f8f9fa; border: 1px solid #e2e4e7; padding: 16px; border-radius: 4px; }
				.wcag-ref { font-size: 12px; color: #646970; }
			</style>
		</head>
		<body>
			<h1>WooCommerce Accessibility Compliance Report</h1>
			<p><strong>Scanned:</strong> <?php echo esc_html( $results['scanned_at'] ); ?></p>

			<h2>Summary</h2>
			<div class="summary-grid">
				<?php foreach ( $results['summary'] as $key => $count ) : ?>
					<?php if ( $count > 0 ) : ?>
						<div class="summary-card">
							<strong><?php echo esc_html( Config::getFixLabel( $key ) ); ?></strong>
							<p style="margin:4px 0;"><?php echo esc_html( $count ); ?> violation(s)</p>
							<span class="wcag-ref">WCAG <?php echo esc_html( Config::WCAG_CRITERIA[ $key ] ?? '?' ); ?></span>
						</div>
					<?php endif; ?>
				<?php endforeach; ?>
			</div>

			<h2>Per-Page Results</h2>
			<?php foreach ( $results['pages'] as $url => $violations ) : ?>
				<?php
				if ( empty( $violations ) ) {
					continue; }
				?>
				<div class="page-section">
					<h3><?php echo esc_url( $url ); ?></h3>
					<?php foreach ( $violations as $key => $v ) : ?>
						<div class="violation severity-<?php echo esc_attr( $v['severity'] ?? 'minor' ); ?>">
							<strong><?php echo esc_html( Config::getFixLabel( $key ) ); ?></strong>
							<p style="margin:4px 0;"><?php echo esc_html( $v['message'] ?? '' ); ?></p>
							<span class="wcag-ref">WCAG <?php echo esc_html( Config::WCAG_CRITERIA[ $key ] ?? '?' ); ?></span>
						</div>
					<?php endforeach; ?>
				</div>
			<?php endforeach; ?>
		</body>
		</html>
		<?php
		return ob_get_clean();
	}
}
