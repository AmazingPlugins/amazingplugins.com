<?php
declare(strict_types=1);

namespace AmazingPlugins\WCAF\Reports;

defined( 'ABSPATH' ) || exit;

/**
 * PDF compliance report builder.
 *
 * Uses DomPDF if the composer autoloader is present;
 * falls back to an HTML-printable report.
 */
class PDF_Builder {

	/**
	 * Generate a compliance report.
	 * Tries DomPDF for a real PDF; falls back to printable HTML.
	 *
	 * @param array $results Scan results from Store_Scanner.
	 * @return string Binary PDF data or HTML string.
	 */
	public static function generate( array $results ): string {
		$html = Report_Generator::generateHTMLReport( $results );

		// Attempt DomPDF if available.
		$autoload = defined( 'WCAF_PLUGIN_DIR' )
			? WCAF_PLUGIN_DIR . 'vendor/autoload.php'
			: dirname( __DIR__, 2 ) . '/vendor/autoload.php';

		if ( file_exists( $autoload ) ) {
			require_once $autoload;

			if ( class_exists( 'Dompdf\Dompdf' ) ) {
				$dompdf = new \Dompdf\Dompdf(
					array(
						'enable_remote' => false,
					)
				);
				$dompdf->loadHtml( $html, 'UTF-8' );
				$dompdf->setPaper( 'A4', 'portrait' );
				$dompdf->render();
				return $dompdf->output();
			}
		}

		// Fallback: return printable HTML.
		return $html;
	}
}
