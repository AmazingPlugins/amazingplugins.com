<?php
declare(strict_types=1);

namespace AmazingPlugins\WCAF\Admin;

defined( 'ABSPATH' ) || exit;

use AmazingPlugins\WCAF\Core\Config;
use AmazingPlugins\WCAF\Core\Logger;
use AmazingPlugins\WCAF\Fixers\Skip_Link_Fixer;
use AmazingPlugins\WCAF\Fixers\Focus_Indicator_Fixer;
use AmazingPlugins\WCAF\Fixers\Keyboard_Trap_Fixer;
use AmazingPlugins\WCAF\Fixers\Alt_Text_Fixer;
use AmazingPlugins\WCAF\Fixers\Form_Label_Fixer;
use AmazingPlugins\WCAF\Fixers\Error_Message_Fixer;
use AmazingPlugins\WCAF\Fixers\Color_Contrast_Fixer;
use AmazingPlugins\WCAF\Fixers\Heading_Hierarchy_Fixer;
use AmazingPlugins\WCAF\Fixers\Landmark_Fixer;

class Fix_Controller {

	private const FIXER_MAP = array(
		'skip_link'         => Skip_Link_Fixer::class,
		'focus_indicator'   => Focus_Indicator_Fixer::class,
		'keyboard_trap'     => Keyboard_Trap_Fixer::class,
		'alt_text_product'  => Alt_Text_Fixer::class,
		'form_label'        => Form_Label_Fixer::class,
		'error_message'     => Error_Message_Fixer::class,
		'color_contrast'    => Color_Contrast_Fixer::class,
		'heading_hierarchy' => Heading_Hierarchy_Fixer::class,
		'landmark'          => Landmark_Fixer::class,
	);

	public static function applyFix(): void {
		// Verify nonce first.
		check_ajax_referer( Admin::NONCE_ACTION_APPLY, 'nonce' );

		// Verify capability.
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized action.', 'amazingplugins-accessibility-fixer-for-woocommerce' ) ), 403 );
		}

		// Sanitize and validate fix key - use filter_input to sanitize at input level.
		$raw_fix_key = filter_input( INPUT_POST, 'fix_key', FILTER_SANITIZE_FULL_SPECIAL_CHARS );
		$raw_fix_key = $raw_fix_key !== null ? wp_unslash( $raw_fix_key ) : '';
		$fix_key     = sanitize_key( $raw_fix_key );

		if ( empty( $fix_key ) || ! array_key_exists( $fix_key, self::FIXER_MAP ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid fix key.', 'amazingplugins-accessibility-fixer-for-woocommerce' ) ), 400 );
		}

		// Check fixer eligibility - all fixers are free and available.

		// Dynamic instantiation is safe here because we validate the key exists in FIXER_MAP.
		$fixer_class = self::FIXER_MAP[ $fix_key ];
		$fixer       = new $fixer_class();

		$applied = $fixer->apply();

		if ( $applied ) {
			// Log to custom table using $wpdb->prepare() for safety.
			global $wpdb;
			$table = $wpdb->prefix . Config::FIX_LOG_TABLE;

			$wpdb->insert(
				$table,
				array(
					'fix_key'    => $fix_key,
					'fix_data'   => wp_json_encode(
						array(
							'applied_by' => get_current_user_id(),
							'applied_at' => current_time( 'mysql' ),
						)
					),
					'applied_at' => current_time( 'mysql' ),
				),
				array( '%s', '%s', '%s' )
			);

			// Persist the applied fix to options so Frontend_Hooks knows to activate it.
			$active_fixes = get_option( 'wcaf_active_fixes', array() );
			if ( ! is_array( $active_fixes ) ) {
				$active_fixes = array();
			}
			if ( ! in_array( $fix_key, $active_fixes, true ) ) {
				$active_fixes[] = $fix_key;
				update_option( 'wcaf_active_fixes', array_unique( $active_fixes ), false );
			}

			wp_send_json_success(
				array( 'message' => __( 'Fix applied successfully.', 'amazingplugins-accessibility-fixer-for-woocommerce' ) )
			);
		}

		Logger::error( 'Fix apply returned false', array( 'fix_key' => $fix_key ) );
		wp_send_json_error( array( 'message' => __( 'Failed to apply fix.', 'amazingplugins-accessibility-fixer-for-woocommerce' ) ), 500 );
	}
}
