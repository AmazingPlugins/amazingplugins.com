<?php
declare(strict_types=1);

namespace AmazingPlugins\WCAF\Admin;

defined( 'ABSPATH' ) || exit;

use AmazingPlugins\WCAF\Core\Config;
class Admin {

	public const NONCE_ACTION_SCAN  = 'wcaf_run_scan';
	public const NONCE_ACTION_APPLY = 'wcaf_apply_fix';

	public static function init(): void {
		add_action( 'admin_menu', array( __CLASS__, 'addMenuPage' ) );
		add_action( 'admin_menu', array( __CLASS__, 'addReportSubmenuPage' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueueAssets' ) );
		add_action( 'admin_post_wcaf_generate_pdf', array( ReportController::class, 'generatePdf' ) );
		add_action( 'wp_ajax_' . self::NONCE_ACTION_SCAN, array( Scan_Controller::class, 'runScan' ) );
		add_action( 'wp_ajax_' . self::NONCE_ACTION_APPLY, array( Fix_Controller::class, 'applyFix' ) );

		// All fixers are available without restriction.
	}

	public static function addMenuPage(): void {
		add_menu_page(
			esc_html__( 'WooCommerce Accessibility', 'amazingplugins-accessibility-fixer-for-woocommerce' ),
			esc_html__( 'WCAG Auto-Fix', 'amazingplugins-accessibility-fixer-for-woocommerce' ),
			'manage_options',
			Config::MENU_SLUG,
			array( Dashboard::class, 'render' ),
			'dashicons-yes-alt',
			80
		);
	}

	public static function addReportSubmenuPage(): void {
		add_submenu_page(
			Config::MENU_SLUG,
			esc_html__( 'Compliance Report', 'amazingplugins-accessibility-fixer-for-woocommerce' ),
			esc_html__( 'View Report', 'amazingplugins-accessibility-fixer-for-woocommerce' ),
			'manage_options',
			'wcaf-report',
			array( ReportController::class, 'renderView' )
		);
	}

	public static function enqueueAssets( string $hook ): void {
		// Only load on our plugin's admin pages.
		$is_our_page = 'toplevel_page_' . Config::MENU_SLUG === $hook
						|| 'wcaf_page_wcaf-report' === $hook;
		if ( ! $is_our_page ) {
			return;
		}

		wp_enqueue_style( 'wcaf-admin', WCAF_PLUGIN_URL . 'assets/css/admin.css', array(), WCAF_VERSION );
		wp_enqueue_script( 'wcaf-admin', WCAF_PLUGIN_URL . 'assets/js/admin.js', array( 'jquery' ), WCAF_VERSION, true );

		wp_localize_script(
			'wcaf-admin',
			'wcaf',
			array(
				'ajaxUrl'    => admin_url( 'admin-ajax.php' ),
				'scanNonce'  => wp_create_nonce( self::NONCE_ACTION_SCAN ),
				'applyNonce' => wp_create_nonce( self::NONCE_ACTION_APPLY ),
				'i18n'       => array(
					'scanning' => esc_html__( 'Scanning…', 'amazingplugins-accessibility-fixer-for-woocommerce' ),
					'rescan'   => esc_html__( 'Rescan', 'amazingplugins-accessibility-fixer-for-woocommerce' ),
					'runScan'  => esc_html__( 'Run Scan Now', 'amazingplugins-accessibility-fixer-for-woocommerce' ),
					'applying' => esc_html__( 'Applying…', 'amazingplugins-accessibility-fixer-for-woocommerce' ),
					'applied'  => esc_html__( 'Applied', 'amazingplugins-accessibility-fixer-for-woocommerce' ),
					'autoFix'  => esc_html__( 'Auto-Fix', 'amazingplugins-accessibility-fixer-for-woocommerce' ),
				),
			)
		);
	}
}
