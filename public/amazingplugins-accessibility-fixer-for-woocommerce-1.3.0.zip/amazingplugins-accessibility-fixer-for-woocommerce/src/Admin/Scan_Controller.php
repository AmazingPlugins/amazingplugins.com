<?php
declare(strict_types=1);

namespace AmazingPlugins\WCAF\Admin;

defined( 'ABSPATH' ) || exit;

use AmazingPlugins\WCAF\Core\Config;
use AmazingPlugins\WCAF\Core\Logger;
use AmazingPlugins\WCAF\Scanner\Store_Scanner;
use AmazingPlugins\WCAF\Scanner\Page_Scanner;

/**
 * Scan_Controller.
 *
 * Handles the front-end scan AJAX request.  Fetches WooCommerce store pages
 * (shop, cart, checkout, my-account, product pages) and runs the Page_Scanner
 * over them.  Uses wc_get_products() which is HPOS-compatible (Works with both
 * DCT and HPOS order storage modes).
 */
class Scan_Controller {

	private const WC_PAGES = array( 'shop', 'cart', 'checkout', 'myaccount', 'thankyou' );

	public static function runScan(): void {
		// Verify nonce.
		check_ajax_referer( Admin::NONCE_ACTION_SCAN, 'nonce' );

		// Verify user capability.
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error(
				array( 'message' => __( 'Unauthorized.', 'amazingplugins-accessibility-fixer-for-woocommerce' ) ),
				403
			);
		}

		$pages   = self::collectPages();
		$scanner = new Store_Scanner( array() );

		foreach ( $pages as $url => $html ) {
			$scanner->addPage( $url, $html );
		}

		$results = $scanner->scan();
		$scanner->saveResults( $results );

		wp_send_json_success(
			array(
				'message'          => __( 'Scan complete.', 'amazingplugins-accessibility-fixer-for-woocommerce' ),
				'pages_scanned'    => count( $pages ),
				'total_violations' => is_array( $results['summary'] )
					? array_sum( $results['summary'] )
					: 0,
			)
		);
	}

	/**
	 * Collect HTML from key WooCommerce pages and product pages.
	 *
	 * HPOS Compatibility: wc_get_products() uses the appropriate data store
	 * based on WooCommerce settings (HPOS vs DCT). wc_get_page_id() always
	 * returns the correct page ID regardless of order storage mode.
	 *
	 * @return array<string,string> URL => HTML
	 */
	private static function collectPages(): array {
		$pages = array();

		// Scan key WooCommerce pages.
		foreach ( self::WC_PAGES as $page_key ) {
			$page_id = wc_get_page_id( $page_key );
			if ( $page_id <= 0 ) {
				continue;
			}
			$url = get_permalink( $page_id );
			if ( ! $url ) {
				continue;
			}
			$url  = esc_url_raw( $url );
			$html = self::fetchPage( $url );
			if ( $html ) {
				$pages[ $url ] = $html;
			}
		}

		// Sample up to 3 published product pages.
		// HPOS: wc_get_products uses wc_get_products() which respects HPOS settings.
		$products = wc_get_products(
			array(
				'limit'   => 3,
				'status'  => 'publish',
				'orderby' => 'rand', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_orderby -- 'rand' is a hardcoded string, not a dynamic variable. WordPress PHPCS ruleset false-positively flags this as a slow query.
				'return'  => 'objects',
			)
		);

		foreach ( $products as $product ) {
			if ( ! $product instanceof \WC_Product ) {
				continue;
			}
			$url = get_permalink( $product->get_id() );
			if ( ! $url ) {
				continue;
			}
			$url  = esc_url_raw( $url );
			$html = self::fetchPage( $url );
			if ( $html && ! isset( $pages[ $url ] ) ) {
				$pages[ $url ] = $html;
			}
		}

		// Front page if distinct from shop.
		$front_page_id = (int) get_option( 'page_on_front' );
		$shop_page_id  = (int) wc_get_page_id( 'shop' );
		if ( $front_page_id > 0 && $front_page_id !== $shop_page_id ) {
			$url = get_permalink( $front_page_id );
			if ( $url ) {
				$url  = esc_url_raw( $url );
				$html = self::fetchPage( $url );
				if ( $html && ! isset( $pages[ $url ] ) ) {
					$pages[ $url ] = $html;
				}
			}
		}

		return $pages;
	}

	/**
	 * Fetch a page with timeout and user-agent header.
	 *
	 * @param string $url Sanitised absolute URL.
	 * @return string Response body or empty string on failure.
	 */
	private static function fetchPage( string $url ): string {
		// Double-check URL is valid and same origin (prevent SSRF to internal hosts).
		if ( ! wp_http_validate_url( $url ) ) {
			Logger::warn( 'Invalid URL rejected for scan', array( 'url' => $url ) );
			return '';
		}

		$host      = wp_parse_url( $url, PHP_URL_HOST );
		$site_host = wp_parse_url( get_site_url(), PHP_URL_HOST );
		if ( $host !== $site_host ) {
			Logger::warn( 'Off-site URL rejected for scan', array( 'url' => $url ) );
			return '';
		}

		$response = wp_remote_get(
			$url,
			array(
				'timeout'    => 15,
				'user-agent' => 'WCAF-Scanner/' . WCAF_VERSION . '; ' . get_site_url(),
				'sslverify'  => true,
			)
		);

		if ( is_wp_error( $response ) ) {
			Logger::error(
				'Scan fetch failed',
				array(
					'url'   => $url,
					'error' => $response->get_error_message(),
				)
			);
			return '';
		}

		$body = wp_remote_retrieve_body( $response );
		return is_string( $body ) ? $body : '';
	}
}
