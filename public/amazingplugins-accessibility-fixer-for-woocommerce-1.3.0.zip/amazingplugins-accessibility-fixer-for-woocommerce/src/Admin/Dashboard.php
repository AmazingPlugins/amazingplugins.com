<?php
declare(strict_types=1);

namespace AmazingPlugins\WCAF\Admin;

defined( 'ABSPATH' ) || exit;

use AmazingPlugins\WCAF\Core\Config;
use AmazingPlugins\WCAF\Scanner\Store_Scanner;

class Dashboard {

	public static function render(): void {
		wp_enqueue_style(
			'wcaf-google-fonts',
			'https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,700;1,9..144,400&family=Inter:wght@400;500;600;700&display=swap',
			array(),
			WCAF_VERSION
		);

		$results    = Store_Scanner::getStoredResults();
		$all_fixes  = Config::ALL_FIXES;
		$scan_nonce = wp_create_nonce( 'wcaf_run_scan_nonce' );

		// Load scan history from transient.
		$history = get_transient( 'wcaf_scan_history' ) ?: array();
		?>

		<div class="wrap wcaf-wrap">
			<h1><?php esc_html_e( 'WooCommerce Accessibility Auto-Fixer', 'amazingplugins-accessibility-fixer-for-woocommerce' ); ?></h1>
			<p class="subtitle"><?php esc_html_e( 'WCAG 2.1 AA compliance made simple', 'amazingplugins-accessibility-fixer-for-woocommerce' ); ?></p>

			<div class="wcaf-cards">
				<div class="wcaf-card">
					<h2><?php esc_html_e( 'Scan', 'amazingplugins-accessibility-fixer-for-woocommerce' ); ?></h2>
					<p><?php esc_html_e( 'Run a full-page scan to discover accessibility violations across your store.', 'amazingplugins-accessibility-fixer-for-woocommerce' ); ?></p>
					<button id="wcaf-run-scan" class="button button-primary" data-nonce="<?php echo esc_attr( $scan_nonce ); ?>">
						<?php esc_html_e( 'Run Scan Now', 'amazingplugins-accessibility-fixer-for-woocommerce' ); ?>
					</button>
					<div id="wcaf-scan-progress" style="display:none;">
						<p><?php esc_html_e( 'Scanning...', 'amazingplugins-accessibility-fixer-for-woocommerce' ); ?> <span id="wcaf-pages-scanned">0</span> <?php esc_html_e( 'pages checked.', 'amazingplugins-accessibility-fixer-for-woocommerce' ); ?></p>
						<div class="wcaf-progress-bar"><div id="wcaf-progress-fill"></div></div>
					</div>
				</div>

				<?php if ( $results ) : ?>
				<div class="wcaf-card">
					<h2><?php esc_html_e( 'Results Summary', 'amazingplugins-accessibility-fixer-for-woocommerce' ); ?></h2>
					<p>
					<?php
					printf(
						/* translators: %d = number of pages scanned */
						esc_html( _n( '%d page scanned', '%d pages scanned', count( $results['pages'] ), 'amazingplugins-accessibility-fixer-for-woocommerce' ) ),
						(int) count( $results['pages'] )
					);
					?>
					</p>
					<ul class="wcaf-violations">
						<?php foreach ( $results['summary'] as $fix_key => $count ) : ?>
							<?php if ( $count > 0 ) : ?>
								<?php
								$fix_label = Config::getFixLabel( $fix_key );
								$wcag_ref  = isset( Config::WCAG_CRITERIA[ $fix_key ] ) ? Config::WCAG_CRITERIA[ $fix_key ] : '?';
								?>
								<li class="wcaf-violation-item">
									<span class="wcaf-fix-label"><?php echo esc_html( $fix_label ); ?></span>
									<span class="wcaf-fix-count"><?php echo esc_html( (string) $count ); ?> issue(s)</span>
									<span class="wcaf-wcag">WCAG <?php echo esc_html( $wcag_ref ); ?></span>
									<button class="button wcaf-apply-fix button-secondary" data-fix="<?php echo esc_attr( $fix_key ); ?>" data-nonce="<?php echo esc_attr( wp_create_nonce( 'wcaf_apply_fix_nonce' ) ); ?>">
										<?php esc_html_e( 'Auto-Fix', 'amazingplugins-accessibility-fixer-for-woocommerce' ); ?>
									</button>
								</li>
							<?php endif; ?>
						<?php endforeach; ?>
					</ul>
					<p>
						<a href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin.php?page=wcaf&report=1' ), 'wcaf_report_nonce', '_wcaf_nonce' ) ); ?>" class="button">
							<?php esc_html_e( 'View Full Report', 'amazingplugins-accessibility-fixer-for-woocommerce' ); ?>
						</a>
					</p>
				</div>
				<?php endif; ?>

				<div class="wcaf-card wcaf-info-card">
					<h2><?php esc_html_e( 'All Fixers Active', 'amazingplugins-accessibility-fixer-for-woocommerce' ); ?></h2>
					<p><?php esc_html_e( 'All 9 auto-fixes are available and ready to apply. Run a scan to get started.', 'amazingplugins-accessibility-fixer-for-woocommerce' ); ?></p>
				</div>
			</div>

			<?php if ( ! empty( $history ) ) : ?>
			<h2 class="wcaf-section-title"><?php esc_html_e( 'Scan History', 'amazingplugins-accessibility-fixer-for-woocommerce' ); ?></h2>
			<table class="widefat striped wcaf-history-table">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Timestamp', 'amazingplugins-accessibility-fixer-for-woocommerce' ); ?></th>
						<th><?php esc_html_e( 'URL', 'amazingplugins-accessibility-fixer-for-woocommerce' ); ?></th>
						<th><?php esc_html_e( 'Violations', 'amazingplugins-accessibility-fixer-for-woocommerce' ); ?></th>
						<th><?php esc_html_e( 'Fixes Applied', 'amazingplugins-accessibility-fixer-for-woocommerce' ); ?></th>
						<th><?php esc_html_e( 'Actions', 'amazingplugins-accessibility-fixer-for-woocommerce' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( array_slice( array_reverse( $history ), 0, 10 ) as $entry ) : ?>
						<tr>
							<td><?php echo esc_html( $entry['timestamp'] ?? '' ); ?></td>
							<td class="column-url"><code><?php echo esc_url( $entry['url'] ?? '' ); ?></code></td>
							<td><?php echo esc_html( (string) ( $entry['violations'] ?? 0 ) ); ?></td>
							<td><?php echo esc_html( (string) ( $entry['fixes_applied'] ?? 0 ) ); ?></td>
							<td>
								<?php if ( ! empty( $entry['url'] ) ) : ?>
									<a href="<?php echo esc_url( $entry['url'] ); ?>" target="_blank" class="button button-small">
										<?php esc_html_e( 'View', 'amazingplugins-accessibility-fixer-for-woocommerce' ); ?>
									</a>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
			<?php endif; ?>

			<h2 class="wcaf-section-title"><?php esc_html_e( 'Accessibility Fixer Settings', 'amazingplugins-accessibility-fixer-for-woocommerce' ); ?></h2>
			<div class="wcaf-card">
				<form method="post" action="options.php" id="wcaf-settings-form">
					<?php settings_fields( Config::SLUG ); ?>
					<table class="form-table">
						<tr>
							<th scope="row"><?php esc_html_e( 'Site URL', 'amazingplugins-accessibility-fixer-for-woocommerce' ); ?></th>
							<td>
								<input type="url" name="wcaf_site_url" value="<?php echo esc_attr( get_option( 'wcaf_site_url', get_site_url() ) ); ?>" class="regular-text">
								<p class="description"><?php esc_html_e( 'The public URL of your store for API calls.', 'amazingplugins-accessibility-fixer-for-woocommerce' ); ?></p>
							</td>
						</tr>
						<tr>
							<th scope="row"><?php esc_html_e( 'Email Notifications', 'amazingplugins-accessibility-fixer-for-woocommerce' ); ?></th>
							<td>
								<label for="wcaf_notify_email">
									<input type="checkbox" id="wcaf_notify_email" name="wcaf_notify_email" value="1" <?php checked( get_option( 'wcaf_notify_email', '0' ), '1' ); ?>>
									<?php esc_html_e( 'Send email when new violations are found after a scan', 'amazingplugins-accessibility-fixer-for-woocommerce' ); ?>
								</label>
							</td>
						</tr>
						<tr>
							<th scope="row"><?php esc_html_e( 'Slack Notifications', 'amazingplugins-accessibility-fixer-for-woocommerce' ); ?></th>
							<td>
								<input type="url" name="wcaf_slack_webhook" value="<?php echo esc_attr( get_option( 'wcaf_slack_webhook', '' ) ); ?>" class="regular-text" placeholder="https://hooks.slack.com/services/...">
								<p class="description"><?php esc_html_e( 'Optional: receive scan summaries in Slack.', 'amazingplugins-accessibility-fixer-for-woocommerce' ); ?></p>
							</td>
						</tr>
					</table>
					<?php submit_button( __( 'Save Settings', 'amazingplugins-accessibility-fixer-for-woocommerce' ) ); ?>
				</form>
			</div>

			<?php if ( $results ) : ?>
			<h2 class="wcaf-section-title"><?php esc_html_e( 'All Auto-Fixers', 'amazingplugins-accessibility-fixer-for-woocommerce' ); ?></h2>
			<div class="wcaf-fixer-panels">
				<?php foreach ( $all_fixes as $fix_key ) : ?>
					<?php
					$fix_label = Config::getFixLabel( $fix_key );
					$wcag_ref  = isset( Config::WCAG_CRITERIA[ $fix_key ] ) ? Config::WCAG_CRITERIA[ $fix_key ] : '?';
					$count     = isset( $results['summary'][ $fix_key ] ) ? (int) $results['summary'][ $fix_key ] : 0;
					$is_active = in_array( $fix_key, get_option( 'wcaf_active_fixes', array() ), true );
					?>
					<div class="wcaf-fixer-panel<?php echo $is_active ? ' open' : ''; ?>">
						<div class="wcaf-fixer-panel-header" onclick="jQuery(this).closest('.wcaf-fixer-panel').toggleClass('open');">
							<h3><?php echo esc_html( $fix_label ); ?></h3>
							<span class="wcaf-wcag">WCAG <?php echo esc_html( $wcag_ref ); ?></span>
						</div>
						<div class="wcaf-fixer-panel-body">
							<div class="wcaf-fixer-row">
								<span class="wcaf-fix-count"><?php echo esc_html( (string) $count ); ?> violation(s) found</span>
								<span class="wcaf-fixer-status <?php echo $is_active ? 'active' : 'inactive'; ?>">
									<?php echo $is_active ? esc_html__( 'Active', 'amazingplugins-accessibility-fixer-for-woocommerce' ) : esc_html__( 'Inactive', 'amazingplugins-accessibility-fixer-for-woocommerce' ); ?>
								</span>
							</div>
							<button class="button wcaf-apply-fix button-secondary" data-fix="<?php echo esc_attr( $fix_key ); ?>" data-nonce="<?php echo esc_attr( wp_create_nonce( 'wcaf_apply_fix_nonce' ) ); ?>">
								<?php echo $is_active ? esc_html__( 'Applied', 'amazingplugins-accessibility-fixer-for-woocommerce' ) : esc_html__( 'Apply Fix', 'amazingplugins-accessibility-fixer-for-woocommerce' ); ?>
							</button>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
			<?php endif; ?>
		</div>
		<?php
	}
}
