<?php
declare(strict_types=1);

namespace AmazingPlugins\WCAF\Frontend;

defined( 'ABSPATH' ) || exit;

use AmazingPlugins\WCAF\Core\Config;

/**
 * Frontend_Hooks.
 *
 * Activates accessibility fixers on the front-end based on user-saved preferences
 * stored in the wcaf_active_fixes option.  Each fixer registers its own hooks
 * (styles, scripts, content filters) when apply() is called.
 */
class Frontend_Hooks {

	private const FIXER_MAP = array(
		'skip_link'         => \AmazingPlugins\WCAF\Fixers\Skip_Link_Fixer::class,
		'focus_indicator'   => \AmazingPlugins\WCAF\Fixers\Focus_Indicator_Fixer::class,
		'keyboard_trap'     => \AmazingPlugins\WCAF\Fixers\Keyboard_Trap_Fixer::class,
		'alt_text_product'  => \AmazingPlugins\WCAF\Fixers\Alt_Text_Fixer::class,
		'form_label'        => \AmazingPlugins\WCAF\Fixers\Form_Label_Fixer::class,
		'error_message'     => \AmazingPlugins\WCAF\Fixers\Error_Message_Fixer::class,
		'color_contrast'    => \AmazingPlugins\WCAF\Fixers\Color_Contrast_Fixer::class,
		'heading_hierarchy' => \AmazingPlugins\WCAF\Fixers\Heading_Hierarchy_Fixer::class,
		'landmark'          => \AmazingPlugins\WCAF\Fixers\Landmark_Fixer::class,
	);

	public static function init(): void {
		// Load only the fixers the admin has applied.
		$applied = get_option( 'wcaf_active_fixes', array() );
		if ( ! is_array( $applied ) ) {
			$applied = array();
		}

		foreach ( $applied as $fix_key ) {
			if ( ! is_string( $fix_key ) ) {
				continue;
			}
			// Sanitize key before using as array index.
			$fix_key = sanitize_key( $fix_key );
			if ( isset( self::FIXER_MAP[ $fix_key ] ) ) {
				$fixer_class = self::FIXER_MAP[ $fix_key ];
				$fixer       = new $fixer_class();
				$fixer->apply();
			}
		}
	}
}
