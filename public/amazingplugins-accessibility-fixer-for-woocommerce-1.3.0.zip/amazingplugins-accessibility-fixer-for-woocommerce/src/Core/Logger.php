<?php
declare(strict_types=1);

namespace AmazingPlugins\WCAF\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Logger.
 *
 * Thin wrapper around WordPress debug logging.  All log calls are gated behind
 * WP_DEBUG.  Context arrays are json-encoded so no user input reaches the log
 * file as raw format strings.
 */
class Logger {

	public const LEVEL_INFO  = 'info';
	public const LEVEL_ERROR = 'error';
	public const LEVEL_DEBUG = 'debug';
	public const LEVEL_WARN  = 'warn';

	private const VALID_LEVELS = array(
		self::LEVEL_INFO  => true,
		self::LEVEL_ERROR => true,
		self::LEVEL_DEBUG => true,
		self::LEVEL_WARN  => true,
	);

	public static function info( string $message, array $context = array() ): void {
		self::log( self::LEVEL_INFO, $message, $context );
	}

	public static function error( string $message, array $context = array() ): void {
		self::log( self::LEVEL_ERROR, $message, $context );
	}

	public static function debug( string $message, array $context = array() ): void {
		self::log( self::LEVEL_DEBUG, $message, $context );
	}

	public static function warn( string $message, array $context = array() ): void {
		self::log( self::LEVEL_WARN, $message, $context );
	}

	private static function log( string $level, string $message, array $context = array() ): void {
		if ( ! defined( 'WP_DEBUG' ) || ! WP_DEBUG ) {
			return;
		}

		// Validate level to prevent format-string injection.
		if ( ! isset( self::VALID_LEVELS[ $level ] ) ) {
			$level = self::LEVEL_DEBUG;
		}

		// NEVER put $message or any user data in the sprintf format string.
		// Use %s placeholders and pass user data as separate arguments.
		$context_json = ! empty( $context ) ? ' ' . wp_json_encode( $context ) : '';
		$log_line     = sprintf(
			'[WCAF][%s] %s%s',
			strtoupper( $level ),
			$message,
			$context_json
		);
	}
}
