<?php
declare(strict_types=1);

namespace AmazingPlugins\WCAF\Core;

defined( 'ABSPATH' ) || exit;

class Config {

	public const SLUG               = 'amazingplugins-accessibility-fixer-for-woocommerce';
	public const MENU_SLUG          = 'wcaf';
	public const SCAN_TRANSIENT     = 'wcaf_scan_results';
	public const FIX_LOG_TABLE      = 'wcaf_fix_log';
	public const SCAN_RESULTS_TABLE = 'wcaf_scan_results';

	public const ALL_FIXES = array(
		'skip_link',
		'focus_indicator',
		'keyboard_trap',
		'alt_text_product',
		'form_label',
		'error_message',
		'color_contrast',
		'heading_hierarchy',
		'landmark',
	);

	public const WCAG_CRITERIA = array(
		'skip_link'         => '2.4.1',
		'focus_indicator'   => '2.4.7',
		'keyboard_trap'     => '2.1.2',
		'alt_text_product'  => '1.1.1',
		'form_label'        => '3.3.2',
		'error_message'     => '3.3.1',
		'color_contrast'    => '1.4.3',
		'heading_hierarchy' => '1.3.1',
		'landmark'          => '1.3.6',
	);

	public static function getFixLabel( string $fix ): string {
		$labels = array(
			'skip_link'         => 'Missing skip-to-content link',
			'focus_indicator'   => 'Insufficient focus indicator',
			'keyboard_trap'     => 'Keyboard navigation traps',
			'alt_text_product'  => 'Missing alt text on product images',
			'form_label'        => 'Form fields missing labels',
			'error_message'     => 'Form error messages not associated',
			'color_contrast'    => 'Insufficient color contrast',
			'heading_hierarchy' => 'Broken heading hierarchy',
			'landmark'          => 'Missing ARIA landmarks',
		);
		return $labels[ $fix ] ?? $fix;
	}
}
