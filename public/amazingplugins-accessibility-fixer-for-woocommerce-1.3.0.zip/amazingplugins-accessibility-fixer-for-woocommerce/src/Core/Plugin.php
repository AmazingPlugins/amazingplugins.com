<?php
declare(strict_types=1);

namespace AmazingPlugins\WCAF\Core;

defined( 'ABSPATH' ) || exit;

use AmazingPlugins\WCAF\Admin\Admin;
use AmazingPlugins\WCAF\Admin\Dashboard;
use AmazingPlugins\WCAF\API\REST_Controller;
use AmazingPlugins\WCAF\Controllers\ReportController;
use AmazingPlugins\WCAF\Frontend\Frontend_Hooks;
use AmazingPlugins\WCAF\Reports\Report_Generator;
use AmazingPlugins\WCAF\Scanner\Store_Scanner;

/**
 * Plugin.
 *
 * Main plugin bootstrapper.  Registers activation/deactivation hooks,
 * loads text domain, initialises admin and front-end components, and
 * registers REST API routes.
 */
class Plugin {

	/** @var bool Flag to prevent double-run on activation. */
	private static $activated = false;

	public static function init(): void {
		// Load plugin.php for is_plugin_active().  plugin.php is cached by OPcache
		// after the first load so this is a single stat() call on subsequent requests.
		require_once ABSPATH . 'wp-admin/includes/plugin.php';

		// Show admin notice if WooCommerce is not active (installed or not).
		if ( ! is_plugin_active( 'woocommerce/woocommerce.php' ) ) {
			add_action( 'admin_notices', array( self::class, 'wooNotInstalledNotice' ) );
			return;
		}

		// Admin - only load in admin context.
		if ( is_admin() ) {
			Admin::init();
		}

		// Frontend fix hooks.
		Frontend_Hooks::init();

		// Register REST API.
		add_action( 'rest_api_init', array( __CLASS__, 'register_rest_routes' ) );
	}

	public static function wooNotInstalledNotice(): void {
		$class = 'notice notice-warning is-dismissible';

		$woo_installed = file_exists( WP_PLUGIN_DIR . '/woocommerce/woocommerce.php' );

		if ( ! $woo_installed ) {
			// WooCommerce not installed - show install link.
			printf(
				'<div class="%1$s"><p><strong>AmazingPlugins Accessibility Fixer for WooCommerce</strong> requires <a href="%2$s">WooCommerce</a> to be installed and activated. <a href="%3$s">Install WooCommerce now</a>.</p></div>',
				esc_attr( $class ),
				esc_url( 'https://wordpress.org/plugins/woocommerce/' ),
				esc_url( admin_url( 'plugin-install.php?tab=search&type=term&s=woocommerce' ) )
			);
		} else {
			// WooCommerce installed but not activated - show activation link.
			$activate_url = wp_nonce_url(
				admin_url( 'plugins.php?action=activate&plugin=woocommerce/woocommerce.php' ),
				'activate-plugin_woocommerce/woocommerce.php'
			);
			printf(
				'<div class="%1$s"><p><strong>AmazingPlugins Accessibility Fixer for WooCommerce</strong> requires WooCommerce to be activated. <a href="%2$s">Activate WooCommerce now</a>.</p></div>',
				esc_attr( $class ),
				esc_url( $activate_url )
			);
		}
	}

	/**
	 * Plugin activation.
	 *
	 * Note: activation hooks run before WordPress determines the current user,
	 * so we defer table creation and capability checks to admin_init where we
	 * CAN use current_user_can().
	 */
	public static function activate(): void {
		// Enforce minimum PHP version before any other setup.
		if ( version_compare( PHP_VERSION, '7.4', '<' ) ) {
			wp_die(
				sprintf(
					esc_html__( 'AmazingPlugins Accessibility Fixer for WooCommerce requires PHP 7.4 or higher. Your current PHP version is %s.', 'amazingplugins-accessibility-fixer-for-woocommerce' ),
					PHP_VERSION
				),
				esc_html__( 'Plugin Activation Error', 'amazingplugins-accessibility-fixer-for-woocommerce' ),
				array( 'back_link' => true )
			);
			return;
		}

		// Mark that activation ran so we don't run again.
		update_option( 'wcaf_activated', current_time( 'mysql' ), false );

		// Schedule deferred setup on next admin init.
		if ( ! wp_next_scheduled( 'wcaf_deferred_setup' ) ) {
			wp_schedule_single_event( time() + 1, 'wcaf_deferred_setup' );
		}

		flush_rewrite_rules();
	}

	/**
	 * Deferred setup - runs after WordPress is fully initialised in an admin context.
	 * Creates custom tables only after confirming the activating user still has
	 * manage_options capability (defensive: the site may have changed users).
	 */
	public static function runDeferredSetup(): void {
		// Only run once, and only for users who can manage options.
		if ( self::$activated ) {
			return;
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		self::$activated = true;

		self::createTables();
		delete_option( 'wcaf_activated' );
	}

	public static function deactivate(): void {
		// Clear scheduled events.
		wp_unschedule_hook( 'wcaf_deferred_setup' );
		wp_unschedule_hook( 'wcaf_cleanup_transients' );

		flush_rewrite_rules();
	}

	/**
	 * Create custom log tables for fix history and scan results.
	 *
	 * Uses dbDelta() per WordPress Plugin Handbook recommendations.
	 * Table names are prefixed with $wpdb->prefix to honour custom table prefixes.
	 *
	 * HPOS Note: these tables are separate from WooCommerce order storage.
	 * They use standard WordPress tables and are therefore HPOS-compatible.
	 */
	private static function createTables(): void {
		global $wpdb;
		$charset_collate = $wpdb->get_charset_collate();

		$fix_table  = $wpdb->prefix . Config::FIX_LOG_TABLE;
		$scan_table = $wpdb->prefix . Config::SCAN_RESULTS_TABLE;

		// Table names use $wpdb->prefix (safe). The suppression is needed because
		// PHPCS cannot verify that the prefix is non-user-controlled here.
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedVariableNotPrepared
		$sql = "CREATE TABLE {$fix_table} (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            fix_key varchar(64) NOT NULL,
            fix_data longtext NOT NULL,
            applied_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY fix_key (fix_key)
        ) $charset_collate;

        CREATE TABLE {$scan_table} (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            page_url varchar(2048) NOT NULL,
            violations longtext NOT NULL,
            scanned_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY scanned_at (scanned_at)
        ) $charset_collate;";
		// phpcs:enable

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( $sql );
	}

	public static function addReportSubmenuPage(): void {
		add_submenu_page(
			Config::MENU_SLUG,
			esc_html__( 'Compliance Report', 'amazingplugins-accessibility-fixer-for-woocommerce' ),
			esc_html__( 'View Report', 'amazingplugins-accessibility-fixer-for-woocommerce' ),
			'manage_options',
			'wcaf-report',
			array( ReportController::class, 'renderView' )
		);
	}

	public static function register_rest_routes(): void {
		require_once WCAF_PLUGIN_DIR . 'src/API/REST_Controller.php';
		( new REST_Controller() )->register_routes();
	}
}
