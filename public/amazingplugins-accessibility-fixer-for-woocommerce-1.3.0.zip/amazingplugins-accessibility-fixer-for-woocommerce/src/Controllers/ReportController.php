<?php
declare(strict_types=1);

namespace AmazingPlugins\WCAF\Controllers;

defined( 'ABSPATH' ) || exit;

use AmazingPlugins\WCAF\Core\Config;
use AmazingPlugins\WCAF\Core\Logger;
use AmazingPlugins\WCAF\Scanner\Store_Scanner;
use AmazingPlugins\WCAF\Reports\Report_Generator;
use AmazingPlugins\WCAF\Reports\PDF_Builder;

/**
 * ReportController.
 *
 * Handles admin report view (GET) and PDF generation (POST).
 *
 * Routes registered in Plugin::register_rest_routes():
 *   GET  /admin/report/{scan_id}       - admin view
 *   POST /admin/report/{scan_id}/pdf  - generate PDF
 */
class ReportController {

	private const NONCE_VIEW = 'wcaf_view_report';
	private const NONCE_PDF  = 'wcaf_pdf_report';

	/**
	 * Render the scan report admin view.
	 *
	 * @param int|null $scan_id Scan record ID (currently uses transient, ID is future-proofing).
	 */
	public static function renderView( ?int $scan_id = null ): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Unauthorized.', 'amazingplugins-accessibility-fixer-for-woocommerce' ) );
		}

		check_admin_referer( self::NONCE_VIEW, '_wcaf_nonce' );

		$results = Store_Scanner::getStoredResults();

		if ( ! $results ) {
			wp_die( esc_html__( 'No scan results found. Please run a scan first.', 'amazingplugins-accessibility-fixer-for-woocommerce' ) );
		}

		$severity_labels = array(
			'critical' => __( 'Critical', 'amazingplugins-accessibility-fixer-for-woocommerce' ),
			'major'    => __( 'Major', 'amazingplugins-accessibility-fixer-for-woocommerce' ),
			'minor'    => __( 'Minor', 'amazingplugins-accessibility-fixer-for-woocommerce' ),
		);

		// Count violations by severity across all pages.
		$by_severity = array(
			'critical' => 0,
			'major'    => 0,
			'minor'    => 0,
		);
		foreach ( $results['pages'] as $page_url => $violations ) {
			foreach ( $violations as $violation ) {
				$sev = $violation['severity'] ?? 'minor';
				if ( isset( $by_severity[ $sev ] ) ) {
					++$by_severity[ $sev ];
				}
			}
		}

		$total_violations = array_sum( $by_severity );
		$scan_timestamp   = esc_html( $results['scanned_at'] );
		$pdf_nonce        = wp_create_nonce( self::NONCE_PDF );

		include WCAF_PLUGIN_DIR . 'resources/views/reports/scan.blade.php';
	}

	/**
	 * Generate and serve a PDF/HTML compliance report.
	 *
	 * @param int|null $scan_id Scan record ID.
	 */
	public static function generatePdf( ?int $scan_id = null ): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized.', 'amazingplugins-accessibility-fixer-for-woocommerce' ) ), 403 );
		}

		check_admin_referer( self::NONCE_PDF, '_wcaf_nonce' );

		$results = Store_Scanner::getStoredResults();

		if ( ! $results ) {
			wp_send_json_error( array( 'message' => __( 'No scan results found.', 'amazingplugins-accessibility-fixer-for-woocommerce' ) ), 404 );
		}

		try {
			$html = PDF_Builder::generate( $results );
		} catch ( \Throwable $e ) {
			Logger::error( 'PDF generation failed', array( 'error' => $e->getMessage() ) );
			wp_send_json_error( array( 'message' => __( 'Failed to generate report.', 'amazingplugins-accessibility-fixer-for-woocommerce' ) ), 500 );
		}

		// Serve as downloadable HTML (print-friendly).
		header( 'Content-Type: text/html; charset=' . get_option( 'blog_charset' ) );
		header( 'Content-Disposition: attachment; filename="accessibility-report-' . gmdate( 'Y-m-d' ) . '.html"' );
		header( 'Cache-Control: no-cache, no-store, must-revalidate' );
		echo $html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Report_Generator uses esc_html() on all dynamic output.
		exit;
	}
}
