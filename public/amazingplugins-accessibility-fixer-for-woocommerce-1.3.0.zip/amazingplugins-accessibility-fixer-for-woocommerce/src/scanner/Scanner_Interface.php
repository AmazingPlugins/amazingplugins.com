<?php
declare(strict_types=1);

namespace AmazingPlugins\WCAF\Scanner;

defined( 'ABSPATH' ) || exit;

interface Scanner_Interface {

	public function scan(): array;
}
