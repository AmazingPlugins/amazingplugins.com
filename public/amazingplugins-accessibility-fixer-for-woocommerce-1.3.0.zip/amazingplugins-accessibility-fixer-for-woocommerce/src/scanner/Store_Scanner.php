<?php
declare(strict_types=1);

namespace AmazingPlugins\WCAF\Scanner;

defined( 'ABSPATH' ) || exit;

use AmazingPlugins\WCAF\Core\Config;
use AmazingPlugins\WCAF\Core\Logger;
use AmazingPlugins\WCAF\Fixers\Fixer_Interface;

class Store_Scanner {

	private array $fixers;
	private array $pages = array();

	public function __construct( array $fixers ) {
		$this->fixers = $fixers;
	}

	public function addPage( string $url, string $html ): void {
		$this->pages[] = array(
			'url'  => $url,
			'html' => $html,
		);
	}

	public function scan(): array {
		$results = array(
			'scanned_at' => current_time( 'mysql' ),
			'pages'      => array(),
			'summary'    => array(),
		);

		$allFixes = array_fill_keys( Config::ALL_FIXES, 0 );

		foreach ( $this->pages as $page ) {
			$scanner                          = new Page_Scanner( $page['url'], $page['html'] );
			$violations                       = $scanner->scan();
			$results['pages'][ $page['url'] ] = $violations;

			foreach ( $violations as $fixKey => $violation ) {
				if ( isset( $allFixes[ $fixKey ] ) ) {
					++$allFixes[ $fixKey ];
				}
			}
		}

		$results['summary'] = $allFixes;
		return $results;
	}

	public function saveResults( array $results ): void {
		set_transient( Config::SCAN_TRANSIENT, $results, DAY_IN_SECONDS );
	}

	public static function getStoredResults(): ?array {
		$results = get_transient( Config::SCAN_TRANSIENT );

		// Validate structure to prevent passing malformed data to the dashboard.
		if ( ! is_array( $results ) ) {
			return null;
		}
		if ( ! array_key_exists( 'scanned_at', $results ) ) {
			return null;
		}
		if ( ! array_key_exists( 'pages', $results ) || ! is_array( $results['pages'] ) ) {
			return null;
		}
		if ( ! array_key_exists( 'summary', $results ) || ! is_array( $results['summary'] ) ) {
			return null;
		}

		return $results;
	}
}
