<?php
declare(strict_types=1);

namespace AmazingPlugins\WCAF\Scanner;

defined( 'ABSPATH' ) || exit;

use DOMDocument;
use DOMXPath;

class Page_Scanner implements Scanner_Interface {

	private string $url;
	private string $html;

	public function __construct( string $url, string $html ) {
		$this->url  = $url;
		$this->html = $html;
	}

	public function scan(): array {
		libxml_use_internal_errors( true );
		$doc = new DOMDocument();
		$doc->loadHTML( mb_convert_encoding( $this->html, 'HTML-ENTITIES', 'UTF-8' ) );
		$xpath      = new DOMXPath( $doc );
		$violations = array();

		// 1. Skip link.
		$skipLinks = $xpath->query( '//a[contains(concat(" ", normalize-space(@class), " "), " skip ") and @href="#"]' );
		if ( $skipLinks->length === 0 ) {
			$violations['skip_link'] = array(
				'severity' => 'critical',
				'element'  => '<a>',
				'message'  => 'No skip-to-content link found',
			);
		}

		// 2. Focus indicator - check elements with outline:none or outline:0 in inline styles.
		$outlineNone = $xpath->query( '//*[contains(@style, "outline:none") or contains(@style, "outline: none")]' );
		if ( $outlineNone->length > 0 ) {
			$violations['focus_indicator'] = array(
				'severity' => 'critical',
				'element'  => 'CSS',
				'message'  => 'Inline outline:none detected',
			);
		}

		// 4 & 5. Missing alt text.
		$imagesWithoutAlt = $xpath->query( '//img[not(@alt) or @alt=""]' );
		if ( $imagesWithoutAlt->length > 0 ) {
			foreach ( $imagesWithoutAlt as $img ) {
				$src = $img->getAttribute( 'src' );
				// Heuristic: product images often in /wp-content/uploads/ or have wc-pbc class.
				$is_product         = strpos( $src, 'wp-content/uploads' ) !== false;
				$key                = $is_product ? 'alt_text_product' : 'alt_text_content';
				$violations[ $key ] = array(
					'severity' => 'major',
					'element'  => '<img src="' . $src . '">',
					'message'  => 'Image missing alt attribute',
				);
			}
		}

		// 6. Form label association.
		$inputs         = $xpath->query( '//input[not(@aria-label) and not(@aria-labelledby) and not(ancestor::label)]' );
		$unlabeledCount = 0;
		foreach ( $inputs as $input ) {
			$type = strtolower( $input->getAttribute( 'type' ) );
			if ( in_array( $type, array( 'hidden', 'submit', 'button', 'reset', 'image' ), true ) ) {
				continue;
			}
			$placeholder      = $input->getAttribute( 'placeholder' );
			$hasImplicitLabel = $input->getAttribute( 'id' ) && $xpath->query( '//label[@for="' . $input->getAttribute( 'id' ) . '"]' )->length > 0;
			if ( ! $placeholder && ! $hasImplicitLabel ) {
				++$unlabeledCount;
			}
		}
		if ( $unlabeledCount > 0 ) {
			$violations['form_label'] = array(
				'severity' => 'major',
				'element'  => '<input>',
				'message'  => "$unlabeledCount input(s) without associated label",
			);
		}

		// 7. Error message - detect aria-describedby pointing to non-existent IDs.
		$inputsWithDesc = $xpath->query( '//input[@aria-describedby]' );
		foreach ( $inputsWithDesc as $input ) {
			$describedBy = $input->getAttribute( 'aria-describedby' );
			$ids         = array_filter( array_map( 'trim', explode( ' ', $describedBy ) ) );
			foreach ( $ids as $id ) {
				if ( $xpath->query( '//*[@id="' . $id . '"]' )->length === 0 ) {
					$violations['error_message'] = array(
						'severity' => 'major',
						'element'  => '<input aria-describedby="' . $id . '">',
						'message'  => 'aria-describedby points to missing element #' . $id,
					);
				}
			}
		}

		// 9. Heading hierarchy.
		$headings      = $xpath->query( '//h1|//h2|//h3|//h4|//h5|//h6' );
		$headingLevels = array();
		foreach ( $headings as $h ) {
			$headingLevels[] = (int) substr( $h->tagName, 1 );
		}
		$hasH1 = in_array( 1, $headingLevels, true );
		if ( ! $hasH1 ) {
			$violations['heading_hierarchy'] = array(
				'severity' => 'major',
				'element'  => '<h1>',
				'message'  => 'No <h1> found on page',
			);
		}
		for ( $i = 1; $i < count( $headingLevels ); $i++ ) {
			$diff = $headingLevels[ $i ] - $headingLevels[ $i - 1 ];
			if ( $diff > 1 ) {
				$violations['heading_hierarchy'] = array(
					'severity' => 'major',
					'element'  => '<h' . $headingLevels[ $i ] . '>',
					'message'  => 'Heading level jump from h' . $headingLevels[ $i - 1 ] . ' to h' . $headingLevels[ $i ],
				);
				break;
			}
		}

		// 10. Missing landmarks.
		$landmarks = array(
			'banner' => '//header[@role="banner" or not(@role)]/ancestor::body',
			'main'   => '//main[@role="main" or not(@role)]',
			'nav'    => '//nav[@role="navigation" or not(@role)]',
		);
		// Simple check: does page have any of these?
		$hasMain = $xpath->query( '//main | //div[@id="main"] | //div[contains(concat(" ",normalize-space(@class)," ")," main ")]' )->length > 0;
		if ( ! $hasMain ) {
			$violations['landmark'] = array(
				'severity' => 'minor',
				'element'  => '<main>',
				'message'  => 'No <main> landmark found',
			);
		}

		return $violations;
	}
}
