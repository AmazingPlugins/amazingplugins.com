<?php
declare(strict_types=1);

namespace AmazingPlugins\WCAF\API;

defined( 'ABSPATH' ) || exit;

use AmazingPlugins\WCAF\Core\Config;
use AmazingPlugins\WCAF\Reports\Report_Generator;
use AmazingPlugins\WCAF\Scanner\Store_Scanner;
use WP_REST_Controller;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

/**
 * REST_Controller.
 *
 * Registers the wcaf/v1 REST API namespace.  All endpoints require
 * authentication via current_user_can( 'manage_options' ).
 * Nonce verification for cookie-authenticated requests is handled
 * automatically by WordPress's REST auth layer.
 */
class REST_Controller extends WP_REST_Controller {

	public function register_routes(): void {
		$this->namespace = 'wcaf/v1';
		register_rest_route(
			$this->namespace,
			'/scan',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'triggerScan' ),
				'permission_callback' => array( $this, 'permissionCheck' ),
			)
		);

		register_rest_route(
			$this->namespace,
			'/report',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'getReport' ),
				'permission_callback' => array( $this, 'permissionCheck' ),
			)
		);

		register_rest_route(
			$this->namespace,
			'/fixes',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'listFixes' ),
				'permission_callback' => array( $this, 'permissionCheck' ),
			)
		);
	}

	/**
	 * Permission callback - verifies the user has admin capabilities.
	 *
	 * For cookie-authenticated admin requests, WordPress's REST auth layer
	 * already handles nonce verification automatically.  No manual nonce check
	 * is needed here.
	 */
	public function permissionCheck( WP_REST_Request $request ): bool {
		return current_user_can( 'manage_options' );
	}

	/**
	 * POST /wcaf/v1/scan - placeholder for bulk agency scan (Phase 3).
	 */
	public function triggerScan( WP_REST_Request $request ): WP_REST_Response {
		return new WP_REST_Response(
			array( 'message' => __( 'Scan endpoint - agency bulk scan coming in Phase 3', 'amazingplugins-accessibility-fixer-for-woocommerce' ) ),
			200
		);
	}

	/**
	 * GET /wcaf/v1/report - return stored scan results.
	 *
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response
	 */
	public function getReport( WP_REST_Request $request ): WP_REST_Response {
		$results = Store_Scanner::getStoredResults();
		if ( ! $results ) {
			return new WP_REST_Response(
				array( 'message' => __( 'No scan results found. Run a scan first.', 'amazingplugins-accessibility-fixer-for-woocommerce' ) ),
				404
			);
		}

		// Whitelist allowed format values - no user input reaches the file system.
		$format = sanitize_key( $request->get_param( 'format' ) ?? 'json' );
		if ( $format === 'html' ) {
			return new WP_REST_Response(
				Report_Generator::generateHTMLReport( $results ),
				200,
				array( 'content-type' => 'text/html; charset=' . get_option( 'blog_charset' ) )
			);
		}

		return new WP_REST_Response( $results, 200 );
	}

	/**
	 * GET /wcaf/v1/fixes - list all available fixes with metadata.
	 */
	public function listFixes(): WP_REST_Response {
		$fixes  = Config::ALL_FIXES;
		$labels = array();
		foreach ( $fixes as $fix ) {
			$labels[ $fix ] = array(
				'label'   => Config::getFixLabel( $fix ),
				'wcag'    => Config::WCAG_CRITERIA[ $fix ] ?? '?',
				'is_free' => true,
			);
		}
		return new WP_REST_Response( $labels, 200 );
	}
}
